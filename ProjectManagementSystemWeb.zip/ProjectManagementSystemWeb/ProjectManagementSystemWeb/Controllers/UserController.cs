﻿using ExcelDataReader;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProjectManagementSystemWeb.DataAccess;
using ProjectManagementSystemWeb.Models;

namespace ProjectManagementSystemWeb.Controllers
{
    public class UserController : Controller
    {
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly ApplicationDbContext _dbContext;

        public UserController(RoleManager<IdentityRole> roleManager, UserManager<IdentityUser> userManager,ApplicationDbContext dbContext)
        {
            _roleManager = roleManager;
            _userManager = userManager;
            _dbContext = dbContext;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var data = _dbContext.ProjectDetails.ToList();
            ViewBag.PMlist = await _userManager.GetUsersInRoleAsync("ProjectManager");
            return View(data);
        }

        [HttpGet]
        public async Task<IActionResult> CreateRole()
        {
            var data = from data1 in _roleManager.Roles
                       select (new RoleVM
                       {
                           RName = data1.Name,
                       });
            return View(data);
        }

        [HttpPost]
        public async Task<IActionResult> CreateRole(string Role)
        {
            if (ModelState.IsValid)
            {
                if (Role != null && !_roleManager.RoleExistsAsync(Role).GetAwaiter().GetResult())
                {
                    await _roleManager.CreateAsync(new IdentityRole(Role));
                    TempData["success"] = "Role Added Successfully";
                    return RedirectToAction("CreateRole");
                }
                TempData["error"] = "Role Already Exist!!!";
                return RedirectToAction("CreateRole");
            }
            return View();
        }


        [HttpGet]
        public IActionResult Upsert(int? id)
        {
            ViewBag.role = _roleManager.Roles.ToList();
            if (id == null)
            {
                EmployeeVM emp = new EmployeeVM();
                return View(emp);
            }
           
            return View();
        }


        [HttpPost]
        public async Task<IActionResult> Upsert(EmployeeVM obj)
        {
           if(obj != null)
            {
                Employee employee = new Employee()
                {
                    Name = obj.Name,
                    Email = obj.Email,
                    UserName = obj.UserName,
                    PhoneNumber = obj.PhoneNumber,
                    EmployeeCode = obj.EmployeeCode,
                    EmployeeType = obj.EmployeeType,
                    JoiningDate = obj.JoiningDate

                };

                await _userManager.CreateAsync(employee, obj.Password);

                await _userManager.AddToRoleAsync(employee, obj.EmployeeType);
                TempData["success"] = "User Added Successfully";
                return RedirectToAction("Index");
            }
              
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> setdata(IFormFile file)
        {
            try
            {
                if (file != null)
                {
                    var supportedTypes = new[] { "xlsx" };
                    var fileExt = System.IO.Path.GetExtension(file.FileName).Substring(1);
                    if (!supportedTypes.Contains(fileExt))
                    {
                        TempData["error"] = "File Extension Is InValid - Only Upload EXCEL File";
                        return RedirectToAction("Index");
                    }

                    var list = new List<Employee>();
                    System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
                    using (var stream = file.OpenReadStream())
                    {
                        using (var reader = ExcelReaderFactory.CreateReader(stream))
                        {
                            while (reader.Read()) //Each row of the file
                            {
                                var data = reader.IsDBNull(0) ? string.Empty : reader.GetString(0);

                                if (data != "")
                                {
                                    list.Add(new Employee
                                    {                                     
                                        Name = reader.GetValue(0).ToString(),
                                        Email = reader.GetValue(1).ToString(),
                                        UserName= reader.GetValue(2).ToString(),
                                        PasswordHash = reader.GetValue(3).ToString(),
                                        PhoneNumber = reader.GetValue(4).ToString(),
                                        EmployeeCode = reader.GetValue(5).ToString(),
                                        EmployeeType = reader.GetValue(6).ToString(),                                                                           
                                        JoiningDate = Convert.ToDateTime(reader.GetValue(7).ToString())
                                    });
                                               
                                }
                                else
                                {
                                    continue;
                                }    

                            }
                            foreach (var item in list)
                            {
                                await _userManager.CreateAsync(item, item.PasswordHash);
                                await _userManager.AddToRoleAsync(item, item.EmployeeType);
                            }
                        }

                    }
                   
                    TempData["success"] = "File Uploaded Successfully";
                    return RedirectToAction("Index");
                }
                TempData["Error"] = "Please Enter File";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }



        [HttpGet]
        public async Task<IActionResult> AddProject()
        {
            var DevloperList = await _userManager.GetUsersInRoleAsync("Developer");          
            ViewBag.DL = DevloperList;
           var pmList = await _userManager.GetUsersInRoleAsync("ProjectManager");         
           ViewBag.PM = pmList;
           return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddProject(ProjectDetailVM obj)
        {
            if(obj != null)
            {
                var UserData = _userManager.FindByIdAsync(obj.ProjectManagerName);

                ProjectDetails data = new ProjectDetails()
                {
                    ProjectName= obj.ProjectName,
                    ProjectDetail = obj.ProjectDetail,
                    ProjectManagerName = obj.ProjectManagerName,
                    DeadlineDate= obj.DeadlineDate,
                };
                _dbContext.ProjectDetails.Add(data);
                _dbContext.SaveChanges();

                ProjectEmployee data1 = new ProjectEmployee()
                {
                    EmployeeId = obj.ProjectManagerName,
                    ProjectId = data.PId
                };

              

                _dbContext.ProjectEmployee.Add(data1);
                _dbContext.SaveChanges();
            }
            return RedirectToAction("Index");
        }



    }
}
