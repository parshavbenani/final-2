﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagementSystemWeb.Models
{
    public class EmployeeVM
    {
        public string Id { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]
        public string Email { get; set; }

        [Required]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,15}$", ErrorMessage = "Password must be between 6 and 20 characters and contain one uppercase letter, one lowercase letter, one digit and one special character.")]
        public string Password { get; set; }


        [StringLength(10, MinimumLength = 10, ErrorMessage = "Please Enter 10 digite valid Mobile Number")]
        public string PhoneNumber { get; set; }
        public string EmployeeCode { get; set; }
        public string EmployeeType { get; set; }
        public DateTime JoiningDate { get; set; }
        public string Name { get; set; }
      
    }
}
